# NexusAI

🤖 Central de Inteligência Artificial com uma interface web moderna.

## Recursos
- Chat com IA
- Geração de imagens
- Geração de vídeos
- Central de IAs com ChatGPT, Gemini, Dreamina, Flow e Veo 3
- Projetos salvos localmente
- Interface responsiva

## Como usar
Abra o arquivo `index.html` em um navegador.

## GitHub Pages
Envie `index.html` e `README.md` para o repositório e ative o GitHub Pages para publicar o site.

> As integrações de IA desta versão são demonstrativas. Para APIs reais, use um backend seguro e nunca publique chaves secretas no HTML.
